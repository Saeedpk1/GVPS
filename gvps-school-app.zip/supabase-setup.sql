-- =============================================================
-- GVPS School App: Supabase setup
-- Paste all of this in Supabase > SQL Editor > New query, then tap Run.
-- Safe to run again later.
-- =============================================================

-- Owner and teachers
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','teacher')),
  name text not null default '',
  phone text not null default '',
  username text not null default '',
  classes text[] not null default '{}',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- All school records: students, payments, attendance, charges, settings
create table if not exists public.records (
  id text primary key,
  col text not null,
  cls text,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists records_col_idx on public.records (col);

-- Helper checks used by the security rules
create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'owner' and active);
$$;

create or replace function public.is_teacher() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'teacher' and active);
$$;

create or replace function public.my_classes() returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce((select classes from public.profiles where id = auth.uid() and role = 'teacher' and active), '{}'::text[]);
$$;

-- The first person to sign in becomes the owner
create or replace function public.claim_owner() returns text
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return 'no'; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and role = 'owner') then return 'owner'; end if;
  if exists (select 1 from public.profiles where role = 'owner') then return 'no'; end if;
  insert into public.profiles (id, role, name) values (auth.uid(), 'owner', 'Owner')
    on conflict (id) do update set role = 'owner', active = true;
  return 'owner';
end;
$$;

grant execute on function public.is_owner(), public.is_teacher(), public.my_classes(), public.claim_owner() to authenticated;
grant select, insert, update, delete on public.profiles, public.records to authenticated;

alter table public.profiles enable row level security;
alter table public.records enable row level security;

-- Profiles: you can read your own. Only the owner adds or changes teachers.
drop policy if exists "profiles read" on public.profiles;
drop policy if exists "profiles insert" on public.profiles;
drop policy if exists "profiles update" on public.profiles;
drop policy if exists "profiles delete" on public.profiles;
create policy "profiles read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_owner());
create policy "profiles insert" on public.profiles for insert to authenticated with check (public.is_owner());
create policy "profiles update" on public.profiles for update to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "profiles delete" on public.profiles for delete to authenticated using (public.is_owner());

-- Records: owner can do everything.
-- Teachers: read school records; add or edit students and attendance of their own classes;
-- add fee receipts for their own classes in their own name. Only the owner cancels receipts.
drop policy if exists "records read" on public.records;
drop policy if exists "records insert" on public.records;
drop policy if exists "records update" on public.records;
drop policy if exists "records delete" on public.records;
create policy "records read" on public.records for select to authenticated
  using (public.is_owner() or public.is_teacher());
create policy "records insert" on public.records for insert to authenticated
  with check (
    public.is_owner()
    or (public.is_teacher() and cls = any (public.my_classes()) and (
         col in ('students','attendance')
         or (col = 'payments' and data->>'byUid' = auth.uid()::text)))
  );
create policy "records update" on public.records for update to authenticated
  using (public.is_owner() or (public.is_teacher() and col in ('students','attendance') and cls = any (public.my_classes())))
  with check (public.is_owner() or (public.is_teacher() and col in ('students','attendance') and cls = any (public.my_classes())));
create policy "records delete" on public.records for delete to authenticated
  using (public.is_owner());

-- Live updates for the owner page
do $$
begin
  begin alter publication supabase_realtime add table public.records; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.profiles; exception when duplicate_object then null; end;
end $$;
